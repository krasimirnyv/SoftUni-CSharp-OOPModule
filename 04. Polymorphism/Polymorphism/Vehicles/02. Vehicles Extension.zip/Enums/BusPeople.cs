namespace Vehicles.Enums;

public enum BusPeople
{
    WithPeople,
    WithoutPeople
}