using Vehicles.Models.Interfaces;

namespace Vehicles.Models;
public abstract class Vehicle : IVehicle
{
    private double _fuelQuantity;
    private double _fuelConsumption;

    protected virtual double AirConditionerIncreasedConsuption => 0;
    protected virtual double RefuelLosses => 1;
    
    protected Vehicle(double fuelQuantity, double fuelConsumption)
    {
        FuelQuantity = fuelQuantity;
        FuelConsumption = fuelConsumption;
    }

    public double FuelQuantity
    {
        get => _fuelQuantity;
        protected set
        {
            if (value < 0)
            {
                throw new ArgumentException("Fuel quantity cannot be negative");
            }

            _fuelQuantity = value;
        }
    }

    public double FuelConsumption 
    { 
        get => _fuelConsumption;
        protected set
        {
            if (value < 0)
            {
                throw new ArgumentException("Fuel consumption cannot be negative");
            }

            _fuelConsumption = value;
        } 
    }

    public string Drive(double distance)
    {
        double fuelNeeded = distance * (FuelConsumption + AirConditionerIncreasedConsuption);
        if (fuelNeeded > FuelQuantity)
        {
            throw new ArgumentException($"{GetType().Name} needs refueling");
        }
        
        FuelQuantity -= fuelNeeded;
        return $"{GetType().Name} travelled {distance} km";
    }

    public void Refuel(double liters)
    {
        if (liters <= 0)
        {
            throw new ArgumentException("Fuel must be a positive number");
        }

        FuelQuantity += liters * RefuelLosses;
    }

    public override string ToString()
        => $"{GetType().Name}: {FuelQuantity:F2}";
}