namespace Vehicles.Models;

public class Truck : Vehicle
{
    
    protected override double AirConditionerIncreasedConsuption => 1.6;
    protected override double RefuelLosses => 0.95;
    
    public Truck(double fuelQuantity, double fuelConsumption)
        : base(fuelQuantity, fuelConsumption)
    {
    }
}