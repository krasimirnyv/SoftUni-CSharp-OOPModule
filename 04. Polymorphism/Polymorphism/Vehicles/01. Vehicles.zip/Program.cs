﻿using Vehicles.Models;
using Vehicles.Models.Interfaces;

namespace Vehicles;
class Program
{
    static void Main(string[] args)
    {
        IVehicle car = CreateVehicle(Console.ReadLine());
        IVehicle truck = CreateVehicle(Console.ReadLine());
        
        Dictionary<string, IVehicle> vehicles = new Dictionary<string, IVehicle>
        {
            { "Car", car },
            { "Truck", truck }
        };
        
        int numberOfCommands = int.Parse(Console.ReadLine());
        for (int i = 0; i < numberOfCommands; i++)
        {
            string[] commandArgs = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string command = commandArgs[0];
            string vehicleType = commandArgs[1];
            double value = double.Parse(commandArgs[2]);
            
            IVehicle vehicle = vehicles[vehicleType];

            try
            {
                switch (command)
                {
                    case "Drive":
                        string driveMessage = vehicle.Drive(value);
                        Console.WriteLine(driveMessage);
                        break;
                    case "Refuel":
                        vehicle.Refuel(value); break;
                }
            }
            catch (ArgumentException exception)
            {
                Console.WriteLine(exception.Message);
            }
        }
        
        foreach (var kvpVehicle in vehicles)
        {
            Console.WriteLine(kvpVehicle.Value);
        }
    }

    private static IVehicle CreateVehicle(string input)
    {
        string[] vehicleInfo = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        string vehicleType = vehicleInfo[0];
        double fuelQuantity = double.Parse(vehicleInfo[1]);
        double fuelConsumption = double.Parse(vehicleInfo[2]);
        
        return vehicleType switch
        {
            "Car" => new Car(fuelQuantity, fuelConsumption),
            "Truck" => new Truck(fuelQuantity, fuelConsumption),
            _ => throw new InvalidOperationException("Unknown vehicle type")
        };
    }
}
