﻿namespace Telephony;

public class StartUp
{
    public static void Main(string[] args)
    {
        string[] phoneNumbers = Console.ReadLine()
            .Split(' ', StringSplitOptions.RemoveEmptyEntries);
        
        string[] urls = Console.ReadLine()
            .Split(' ', StringSplitOptions.RemoveEmptyEntries);

        ICallable telephone;
        foreach (string number in phoneNumbers)
        {
            if (number.Length == 10)
                telephone = new Smartphone();
            else // number.Length == 7
                telephone = new StationaryPhone();
            try
            {
                Console.WriteLine(telephone.Call(number));
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
        }
        
        IBrowsable browser;
        foreach (string url in urls)
        {
            browser = new Smartphone();
            
            try
            {
                Console.WriteLine(browser.Browse(url));
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
        }
    }
}