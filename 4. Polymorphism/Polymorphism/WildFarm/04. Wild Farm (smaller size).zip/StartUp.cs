﻿using WildFarm.Factories;
using WildFarm.Factories.Interfaces;
using WildFarm.Models.Interfaces;

namespace WildFarm;

public class StartUp
{
    public static void Main(string[] args)
    {
        IAnimalFactory animalFactory = new AnimalFactory();
        IFoodFactory foodFactory = new FoodFactory();
        ICollection<IAnimal> animals = new List<IAnimal>();
       
        string input = default;
        while ((input = Console.ReadLine()) != "End")
        {
            IAnimal animal = null;
            
            try
            {
                animal = CreateAnimal(input, animalFactory);
                IFood food = CreateFood(foodFactory);
                
                Console.WriteLine(animal.ProduceSound());
                animal.Eat(food);
            }
            catch (ArgumentException exception)
            {
                Console.WriteLine(exception.Message);
            }
            
            animals.Add(animal);

        }

        foreach (IAnimal animal in animals)
        {
            Console.WriteLine(animal);
        }
    }
    
    private static IAnimal CreateAnimal(string input, IAnimalFactory animalFactory)
    {
        string[] animalArgs = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        IAnimal animal = animalFactory.CreateAnimal(animalArgs); 
        
        return animal;
    }
    
    private static IFood CreateFood(IFoodFactory foodFactory)
    {
        string[] foodArgs = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        
        string foodType = foodArgs[0];
        int foodQuantity = int.Parse(foodArgs[1]);

        IFood food = foodFactory.CreateFood(foodType, foodQuantity);

        return food;
    }
}