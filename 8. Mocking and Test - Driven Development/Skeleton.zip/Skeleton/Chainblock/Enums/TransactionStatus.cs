﻿namespace Chainblock.Enums;

public enum TransactionStatus
{
    Failed,
    Successful,
    Aborted,
    Unauthorised
}