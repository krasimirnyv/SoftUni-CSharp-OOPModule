﻿namespace BorderControl;

public class StartUp
{
    public static void Main(string[] args)
    {
        List<IIdentifiable> crossers = new List<IIdentifiable>();
        
        string input = default;
        while ((input = Console.ReadLine()) != "End")
        {
            string[] tokens = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            
            switch (tokens.Length)
            {
                case 3:
                    string name = tokens[0];
                    int age = int.Parse(tokens[1]);
                    string id = tokens[2];
                    crossers.Add(new Citizen(name, age, id));
                    break;
                case 2:
                    string model = tokens[0];
                    id = tokens[1];
                    crossers.Add(new Robot(model, id));
                    break;
            }
        }
        
        string lastDigitsFakeId = Console.ReadLine();

        foreach (var identify in crossers)
        {
            if (identify.Id.EndsWith(lastDigitsFakeId))
            {
                Console.WriteLine(identify.Id);
            }
        }
    }
}