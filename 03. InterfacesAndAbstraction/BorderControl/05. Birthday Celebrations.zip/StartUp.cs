﻿namespace BorderControl;

public class StartUp
{
    public static void Main(string[] args)
    {
        List<IBirthable> birthdays = new List<IBirthable>();
        
        string input = default;
        while ((input = Console.ReadLine()) != "End")
        {
            string[] tokens = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);

            string type = tokens[0];
            switch (type)
            {
                case "Citizen":
                    string name = tokens[1];
                    int age = int.Parse(tokens[2]);
                    string id = tokens[3];
                    string birthdate = tokens[4];
                    birthdays.Add(new Citizen(name, age, id, birthdate));
                    break;
                case "Pet":
                    name = tokens[1];
                    birthdate = tokens[2];
                    birthdays.Add(new Pet(name, birthdate));
                    break;
            }
        }
        
        string specificYear = Console.ReadLine();

        foreach (var date in birthdays)
        {
            if (date.Birthdate.EndsWith(specificYear))
            {
                Console.WriteLine(date.Birthdate);
            }
        }
    }
}