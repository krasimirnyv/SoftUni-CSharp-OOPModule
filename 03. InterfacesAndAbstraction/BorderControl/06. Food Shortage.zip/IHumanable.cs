namespace BorderControl;

public interface IHumanable
{
    int Age { get; }
}