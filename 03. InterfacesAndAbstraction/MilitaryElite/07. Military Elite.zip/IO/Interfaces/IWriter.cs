namespace MilitaryElite.IO.Interfaces;

public interface IWriter
{
    void WriteLine(string line);
}