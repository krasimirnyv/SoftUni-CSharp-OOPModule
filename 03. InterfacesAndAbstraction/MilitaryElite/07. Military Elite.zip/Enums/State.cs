namespace MilitaryElite.Enums;

public enum State
{
    InProgress,
    Finished
}