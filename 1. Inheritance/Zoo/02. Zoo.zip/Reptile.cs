namespace Zoo;

public abstract class Reptile : Animal
{
    protected Reptile(string name) : base(name)
    {
    }
}